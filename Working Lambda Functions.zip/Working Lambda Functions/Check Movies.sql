USE moviesdatabase;

Select * from Movies;

DROP USER IF EXISTS 'moviesdatabase-read-only';
DROP USER IF EXISTS 'moviesdatabase-read-write';

CREATE USER 'moviesdatabase-read-only' IDENTIFIED BY 'abc123!!';
CREATE USER 'moviesdatabase-read-write' IDENTIFIED BY 'def456!!';

GRANT SELECT, SHOW VIEW ON moviesdatabase.* 
      TO 'moviesdatabase-read-only';
GRANT SELECT, SHOW VIEW, INSERT, UPDATE, DELETE, DROP, CREATE, ALTER ON moviesdatabase.* 
      TO 'moviesdatabase-read-write';
      
FLUSH PRIVILEGES;

