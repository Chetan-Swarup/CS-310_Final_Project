CREATE DATABASE IF NOT EXISTS moviesdatabase;

USE moviesdatabase;

CREATE TABLE Movies (
    Movie_id INT AUTO_INCREMENT PRIMARY KEY,
    Movie_Name VARCHAR(255),
    Actor VARCHAR(255),
    Genre VARCHAR(100),
    Imdb_Rating DECIMAL(3, 1),
    Domestic_Box_Office VARCHAR(50),
    International_Box_Office VARCHAR(50),
    Total_Collection VARCHAR(50),
    Rotten_Tomatoes_Critic VARCHAR(10),
    Rotten_Tomatoes_Fan VARCHAR(10)
);

INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('Top Gun: Maverick', 'Tom Cruise', 'Action', 8.4, '$718.7M', '$770.0M', '$1488.7M', '96%', '99%'),
('Mission: Impossible - Fallout', 'Tom Cruise', 'Action', 7.7, '$220.2M', '$487.7M', '$707.9M', '97%', '88%'),
('Jerry Maguire', 'Tom Cruise', 'Comedy', 7.3, '$153.6M', '$119.6M', '$273.2M', '84%', '79%'),
('A Few Good Men', 'Tom Cruise', 'Drama', 7.7, '$141.3M', '$101.0M', '$242.3M', '83%', '89%'),
('Rain Man', 'Tom Cruise', 'Drama', 8.0, '$172.8M', '$247.6M', '$420.4M', '89%', '90%'),
('Collateral', 'Tom Cruise', 'Crime', 7.5, '$101.0M', '$116.8M', '$217.8M', '86%', '84%'),
('Magnolia', 'Tom Cruise', 'Drama', 8.0, '$22.5M', '$25.9M', '$48.4M', '83%', '89%'),
('Mission: Impossible - Ghost Protocol', 'Tom Cruise', 'Action', 7.4, '$209.4M', '$485.3M', '$694.7M', '93%', '76%'),
('Edge of Tomorrow', 'Tom Cruise', 'Action', 7.9, '$100.2M', '$270.3M', '$370.5M', '91%', '90%'),
('Minority Report', 'Tom Cruise', 'Action', 7.6, '$132.1M', '$226.3M', '$358.4M', '90%', '80%'),
('The Last Samurai', 'Tom Cruise', 'Action', 7.7, '$111.1M', '$345.6M', '$456.7M', '66%', '83%'),
('War of the Worlds', 'Tom Cruise', 'Adventure', 6.5, '$234.3M', '$357.5M', '$591.8M', '75%', '42%'),
('Mission: Impossible - Rogue Nation', 'Tom Cruise', 'Action', 7.4, '$195.0M', '$487.3M', '$682.3M', '94%', '87%'),
('Mission: Impossible', 'Tom Cruise', 'Action', 7.1, '$180.9M', '$276.7M', '$457.6M', '66%', '71%'),
('Mission: Impossible II', 'Tom Cruise', 'Action', 6.1, '$215.4M', '$331.0M', '$546.4M', '57%', '42%'),
('Mission: Impossible III', 'Tom Cruise', 'Action', 6.9, '$134.0M', '$263.8M', '$397.8M', '71%', '69%'),
('Top Gun', 'Tom Cruise', 'Action', 6.9, '$180.3M', '$177.0M', '$357.3M', '58%', '83%'),
('The Mummy', 'Tom Cruise', 'Action', 5.4, '$80.1M', '$329.0M', '$409.1M', '16%', '35%'),
('Oblivion', 'Tom Cruise', 'Action', 7.0, '$89.1M', '$197.1M', '$286.2M', '53%', '61%'),
('Jack Reacher', 'Tom Cruise', 'Action', 7.0, '$80.1M', '$138.3M', '$218.4M', '63%', '67%');

INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('The Dark Knight', 'Christian Bale', 'Action', 9, '$534.9M', '$469.7M', '$1004.6M', '94%', '94%'),
('American Psycho', 'Christian Bale', 'Drama', 7.6, '$15.1M', '$19.3M', '$34.4M', '69%', '85%'),
('The Prestige', 'Christian Bale', 'Drama', 8.5, '$53.1M', '$55.0M', '$108.1M', '76%', '92%'),
('Batman Begins', 'Christian Bale', 'Action', 8.2, '$206.9M', '$167.4M', '$374.3M', '84%', '94%'),
('Ford v Ferrari', 'Christian Bale', 'Action', 8.1, '$117.6M', '$107.9M', '$225.5M', '92%', '98%'),
('The Fighter', 'Christian Bale', 'Biography', 7.8, '$93.6M', '$35.5M', '$129.1M', '91%', '89%'),
('Vice', 'Christian Bale', 'Biography', 7.2, '$47.8M', '$42.0M', '$89.8M', '65%', '56%'),
('American Hustle', 'Christian Bale', 'Crime', 7.2, '$150.1M', '$101.1M', '$251.2M', '92%', '74%'),
('The Machinist', 'Christian Bale', 'Drama', 7.7, '$1.1M', '$7.9M', '$9M', '77%', '83%'),
('3:10 to Yuma', 'Christian Bale', 'Action', 7.7, '$53.6M', '$16.4M', '$70M', '89%', '86%'),
('The Big Short', 'Christian Bale', 'Biography', 7.8, '$70.3M', '$63.2M', '$133.5M', '89%', '88%'),
('Rescue Dawn', 'Christian Bale', 'Biography', 7.3, '$5.5M', '$1.5M', '$7M', '90%', '82%'),
('Public Enemies', 'Christian Bale', 'Biography', 7, '$97.1M', '$117.0M', '$214.1M', '68%', '59%'),
('Out of the Furnace', 'Christian Bale', 'Action', 6.8, '$11.3M', '$5.3M', '$16.6M', '53%', '51%'),
('Hostiles', 'Christian Bale', 'Adventure', 7.2, '$29.8M', '$5.8M', '$35.6M', '71%', '72%'),
('Equilibrium', 'Christian Bale', 'Action', 7.4, '$1.2M', '$4.1M', '$5.3M', '40%', '81%'),
('Reign of Fire', 'Christian Bale', 'Action', 6.2, '$43.1M', '$39.0M', '$82.1M', '42%', '49%'),
('Exodus: Gods and Kings', 'Christian Bale', 'Action', 6, '$65.0M', '$203.0M', '$268M', '31%', '37%'),
('The Dark Knight Rises', 'Christian Bale', 'Action', 8.4, '$448.1M', '$636.8M', '$1084.9M', '87%', '90%'),
('Empire of the Sun', 'Christian Bale', 'Drama', 7.7, '$22.2M', '$44.5M', '$66.7M', '75%', '89%');

INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('Skyfall', 'Judi Dench', 'Action', 7.8, '$304.4M', '$804.2M', '$1108.6M', '92%', '86%'),
('Shakespeare in Love', 'Judi Dench', 'Comedy', 7.1, '$100.3M', '$189.3M', '$289.6M', '92%', '80%'),
('Philomena', 'Judi Dench', 'Biography', 7.6, '$37.7M', '$61.0M', '$98.7M', '91%', '89%'),
('Casino Royale', 'Judi Dench', 'Action', 8, '$167.4M', '$594.4M', '$761.8M', '94%', '90%'),
('The Best Exotic Marigold Hotel', 'Judi Dench', 'Comedy', 7.2, '$46.4M', '$90.5M', '$136.9M', '78%', '74%'),
('Notes on a Scandal', 'Judi Dench', 'Drama', 7.4, '$17.5M', '$30.0M', '$47.5M', '87%', '81%'),
('Mrs. Brown', 'Judi Dench', 'Biography', 7.2, '$9.2M', '$13.6M', '$22.8M', '92%', '84%'),
('The Importance of Being Earnest', 'Judi Dench', 'Comedy', 6.8, '$8.4M', '$8.4M', '$16.8M', '57%', '61%'),
('Chocolat', 'Judi Dench', 'Drama', 7.2, '$71.5M', '$87.0M', '$158.5M', '63%', '83%'),
('The Chronicles of Riddick', 'Judi Dench', 'Action', 6.7, '$57.8M', '$58.0M', '$115.8M', '29%', '65%'),
('Quantum of Solace', 'Judi Dench', 'Action', 6.6, '$168.4M', '$417.7M', '$586.1M', '64%', '58%'),
('Pride & Prejudice', 'Judi Dench', 'Drama', 7.8, '$38.4M', '$121.1M', '$159.5M', '86%', '89%'),
('The Shipping News', 'Judi Dench', 'Drama', 6.7, '$11.4M', '$18.0M', '$29.4M', '74%', '67%'),
('Die Another Day', 'Judi Dench', 'Action', 6.1, '$160.9M', '$271.0M', '$431.9M', '56%', '41%'),
('The World Is Not Enough', 'Judi Dench', 'Action', 6.4, '$126.9M', '$361.7M', '$488.6M', '52%', '49%'),
('A Room with a View', 'Judi Dench', 'Drama', 7.3, '$20.9M', '$68.0M', '$88.9M', '100%', '85%'),
('Iris', 'Judi Dench', 'Biography', 7.1, '$5.6M', '$14.0M', '$19.6M', '79%', '74%'),
('Mrs. Henderson Presents', 'Judi Dench', 'Biography', 7, '$11.0M', '$20.0M', '$31M', '67%', '75%'),
('Victoria & Abdul', 'Judi Dench', 'Biography', 6.8, '$22.2M', '$47.0M', '$69.2M', '66%', '66%'),
('Belfast', 'Judi Dench', 'Drama', 7.2, '$9.3M', '$49.0M', '$58.3M', '87%', '84%');


INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('Gravity', 'Sandra Bullock', 'Sci-Fi', 7.7, '$274.1M', '$449.1M', '$723.2M', '96%', '79%'),
('The Blind Side', 'Sandra Bullock', 'Biography', 7.6, '$256.0M', '$53.0M', '$309M', '66%', '85%'),
('Speed', 'Sandra Bullock', 'Action', 7.3, '$121.2M', '$229.2M', '$350.4M', '95%', '76%'),
('The Proposal', 'Sandra Bullock', 'Comedy', 6.7, '$163.9M', '$157.3M', '$321.2M', '45%', '67%'),
('Miss Congeniality', 'Sandra Bullock', 'Comedy', 6.3, '$106.8M', '$105.9M', '$212.7M', '42%', '69%'),
('Ocean\'s 8', 'Sandra Bullock', 'Action', 6.3, '$140.2M', '$157.0M', '$297.2M', '69%', '45%'),
('The Heat', 'Sandra Bullock', 'Action', 6.6, '$159.6M', '$70.3M', '$229.9M', '66%', '71%'),
('Bullet Train', 'Sandra Bullock', 'Action', 6.8, '$103.4M', '$135.9M', '$239.3M', '53%', '76%'),
('A Time to Kill', 'Sandra Bullock', 'Crime', 7.5, '$108.7M', '$43.5M', '$152.2M', '67%', '85%'),
('While You Were Sleeping', 'Sandra Bullock', 'Comedy', 6.7, '$81.1M', '$59.0M', '$140.1M', '81%', '79%'),
('Two Weeks Notice', 'Sandra Bullock', 'Comedy', 6.1, '$93.3M', '$105.7M', '$199M', '42%', '63%'),
('The Lake House', 'Sandra Bullock', 'Drama', 6.8, '$52.3M', '$62.5M', '$114.8M', '35%', '73%'),
('Practical Magic', 'Sandra Bullock', 'Comedy', 6.3, '$46.7M', '$68.3M', '$115M', '22%', '73%'),
('The Net', 'Sandra Bullock', 'Action', 5.9, '$50.7M', '$84.0M', '$134.7M', '36%', '53%'),
('The Lost City', 'Sandra Bullock', 'Action', 6.1, '$105.3M', '$104.9M', '$210.2M', '79%', '83%'),
('Premonition', 'Sandra Bullock', 'Drama', 5.9, '$47.9M', '$84.1M', '$132M', '8%', '29%'),
('Infamous', 'Sandra Bullock', 'Biography', 7, '$1.0M', '$2.0M', '$3M', '73%', '67%'),
('All About Steve', 'Sandra Bullock', 'Romantic', 4.8, '$33M', '$9M', '$42M', '6%', '29%'),
('The Heat', 'Sandra Bullock', 'Action', 6.6, '$159.6M', '$70.3M', '$229.9M', '66%', '71%'),
('Minions', 'Sandra Bullock', 'Animation', 6.4, '$336.0M', '$823.4M', '$1159.4M', '55%', '49%');

INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('The Devil Wears Prada', 'Meryl Streep', 'Comedy', 6.9, '$124.7M', '$202.0M', '$326.7M', '75%', '76%'),
('Mamma Mia!', 'Meryl Streep', 'Comedy', 6.5, '$144.1M', '$465.7M', '$609.8M', '55%', '66%'),
('Mamma Mia! Here We Go Again', 'Meryl Streep', 'Comedy', 6.6, '$120.6M', '$278.7M', '$399.3M', '79%', '66%'),
('The Iron Lady', 'Meryl Streep', 'Biography', 6.4, '$30.0M', '$84.9M', '$114.9M', '52%', '51%'),
('Julie & Julia', 'Meryl Streep', 'Biography', 7, '$94.1M', '$26.7M', '$120.8M', '77%', '70%'),
('Into the Woods', 'Meryl Streep', 'Adventure', 5.9, '$128.0M', '$85.1M', '$213.1M', '71%', '49%'),
('Doubt', 'Meryl Streep', 'Drama', 7.5, '$33.4M', '$22.9M', '$56.3M', '79%', '78%'),
('The Post', 'Meryl Streep', 'Biography', 7.2, '$81.9M', '$89.7M', '$171.6M', '88%', '72%'),
('Florence Foster Jenkins', 'Meryl Streep', 'Biography', 6.8, '$27.4M', '$29.3M', '$56.7M', '87%', '66%'),
('The Bridges of Madison County', 'Meryl Streep', 'Drama', 7.6, '$71.5M', '$110.5M', '$182M', '90%', '87%'),
('Out of Africa', 'Meryl Streep', 'Biography', 7.2, '$87.1M', '$128.5M', '$215.6M', '61%', '83%'),
('Kramer vs. Kramer', 'Meryl Streep', 'Drama', 7.8, '$106.3M', '$173.0M', '$279.3M', '89%', '88%'),
('Adaptation', 'Meryl Streep', 'Comedy', 7.7, '$22.5M', '$10.0M', '$32.5M', '91%', '85%'),
('The Hours', 'Meryl Streep', 'Drama', 7.5, '$41.7M', '$52.0M', '$93.7M', '81%', '81%'),
('The Deer Hunter', 'Meryl Streep', 'Drama', 8.1, '$49.0M', '$30.0M', '$79M', '86%', '92%'),
('Silkwood', 'Meryl Streep', 'Biography', 7.2, '$35.6M', '$15.0M', '$50.6M', '75%', '72%'),
('The Manchurian Candidate', 'Meryl Streep', 'Drama', 6.6, '$65.9M', '$30.1M', '$96M', '81%', '63%'),
('It\'s Complicated', 'Meryl Streep', 'Comedy', 6.5, '$112.7M', '$106.6M', '$219.3M', '58%', '57%'),
('The River Wild', 'Meryl Streep', 'Action', 6.4, '$46.8M', '$94.2M', '$141M', '57%', '53%'),
('August: Osage County', 'Meryl Streep', 'Comedy', 7.2, '$37.7M', '$20.0M', '$57.7M', '64%', '64%');

INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('American Gangster', 'Denzel Washington', 'Biography', 7.8, '$130.2M', '$137.4M', '$267.6M', '80%', '87%'),
('Remember the Titans', 'Denzel Washington', 'Biography', 7.8, '$115.7M', '$21.0M', '$136.7M', '73%', '93%'),
('Glory', 'Denzel Washington', 'Biography', 7.8, '$26.8M', '$15.0M', '$41.8M', '93%', '94%'),
('Training Day', 'Denzel Washington', 'Crime', 7.7, '$76.6M', '$28.0M', '$104.6M', '73%', '89%'),
('Man on Fire', 'Denzel Washington', 'Action', 7.7, '$77.9M', '$52.0M', '$129.9M', '39%', '89%'),
('Philadelphia', 'Denzel Washington', 'Drama', 7.7, '$77.3M', '$129.2M', '$206.5M', '80%', '89%'),
('Malcolm X', 'Denzel Washington', 'Biography', 7.7, '$48.2M', '$9.8M', '$58M', '88%', '91%'),
('Inside Man', 'Denzel Washington', 'Crime', 7.6, '$88.5M', '$95.8M', '$184.3M', '86%', '85%'),
('The Hurricane', 'Denzel Washington', 'Biography', 7.6, '$50.7M', '$29.0M', '$79.7M', '83%', '87%'),
('The Equalizer', 'Denzel Washington', 'Action', 7.2, '$101.5M', '$90.8M', '$192.3M', '60%', '76%'),
('The Book of Eli', 'Denzel Washington', 'Action', 6.9, '$94.8M', '$62.0M', '$156.8M', '47%', '64%'),
('Safe House', 'Denzel Washington', 'Action', 6.7, '$126.4M', '$81.7M', '$208.1M', '53%', '63%'),
('Deja Vu', 'Denzel Washington', 'Action', 7.1, '$64.0M', '$116.5M', '$180.5M', '55%', '70%'),
('The Magnificent Seven', 'Denzel Washington', 'Action', 6.9, '$93.4M', '$68.9M', '$162.3M', '64%', '72%'),
('Fences', 'Denzel Washington', 'Drama', 7.2, '$57.7M', '$6.7M', '$64.4M', '92%', '80%'),
('Flight', 'Denzel Washington', 'Drama', 7.3, '$93.8M', '$68.0M', '$161.8M', '77%', '75%'),
('The Bone Collector', 'Denzel Washington', 'Crime', 6.7, '$66.5M', '$88.0M', '$154.5M', '28%', '63%'),
('Crimson Tide', 'Denzel Washington', 'Action', 7.3, '$91.4M', '$66.0M', '$157.4M', '88%', '83%'),
('The Pelican Brief', 'Denzel Washington', 'Crime', 6.6, '$100.8M', '$94.5M', '$195.3M', '53%', '74%'),
('Unstoppable', 'Denzel Washington', 'Action', 6.8, '$81.5M', '$86.2M', '$167.7M', '87%', '74%');

INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('Forrest Gump', 'Tom Hanks', 'Drama', 8.8, '$330.5M', '$347.7M', '$678.2M', '71%', '95%'),
('Saving Private Ryan', 'Tom Hanks', 'Drama', 8.6, '$216.5M', '$265.3M', '$481.8M', '93%', '95%'),
('Cast Away', 'Tom Hanks', 'Adventure', 7.8, '$233.6M', '$196.0M', '$429.6M', '89%', '84%'),
('Toy Story', 'Tom Hanks', 'Animation', 8.3, '$191.8M', '$181.8M', '$373.6M', '100%', '92%'),
('Apollo 13', 'Tom Hanks', 'Adventure', 7.7, '$173.8M', '$187.0M', '$360.8M', '96%', '87%'),
('The Green Mile', 'Tom Hanks', 'Crime', 8.6, '$136.8M', '$150.0M', '$286.8M', '79%', '94%'),
('Catch Me If You Can', 'Tom Hanks', 'Biography', 8.1, '$164.6M', '$187.5M', '$352.1M', '96%', '89%'),
('Captain Phillips', 'Tom Hanks', 'Biography', 7.8, '$107.1M', '$111.7M', '$218.8M', '93%', '89%'),
('A Beautiful Day in the Neighborhood', 'Tom Hanks', 'Biography', 7.3, '$61.7M', '$14.4M', '$76.1M', '95%', '92%'),
('Bridge of Spies', 'Tom Hanks', 'Drama', 7.6, '$72.3M', '$93.0M', '$165.3M', '91%', '87%'),
('Sully', 'Tom Hanks', 'Biography', 7.4, '$125.1M', '$115.7M', '$240.8M', '85%', '84%'),
('The Post', 'Tom Hanks', 'Biography', 7.2, '$81.9M', '$89.7M', '$171.6M', '88%', '72%'),
('The Terminal', 'Tom Hanks', 'Comedy', 7.4, '$77.9M', '$141.0M', '$218.9M', '61%', '74%'),
('Sleepless in Seattle', 'Tom Hanks', 'Comedy', 6.8, '$126.7M', '$101.1M', '$227.8M', '75%', '73%'),
('You\'ve Got Mail', 'Tom Hanks', 'Comedy', 6.7, '$115.8M', '$135.0M', '$250.8M', '69%', '73%'),
('Big', 'Tom Hanks', 'Comedy', 7.3, '$114.9M', '$36.1M', '$151M', '97%', '82%'),
('Philadelphia', 'Tom Hanks', 'Drama', 7.7, '$77.3M', '$129.2M', '$206.5M', '80%', '89%'),
('Road to Perdition', 'Tom Hanks', 'Crime', 7.7, '$104.5M', '$76.5M', '$181M', '81%', '86%'),
('Cloud Atlas', 'Tom Hanks', 'Drama', 7.4, '$27.1M', '$103.4M', '$130.5M', '66%', '66%'),
('The Polar Express', 'Tom Hanks', 'Animation', 6.6, '$189.1M', '$126.3M', '$315.4M', '56%', '63%');


INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('The Good', 'Clint Eastwood', 'Western', 8.8, '$25.1M', '$6.1M', '$31.2M', '97%', '97%'),
('Unforgiven', 'Clint Eastwood', 'Western', 8.2, '$101.2M', '$58.0M', '$159.2M', '96%', '93%'),
('Million Dollar Baby', 'Clint Eastwood', 'Drama', 8.1, '$100.5M', '$116.3M', '$216.8M', '90%', '90%'),
('Gran Torino', 'Clint Eastwood', 'Drama', 8.1, '$148.1M', '$121.9M', '$270M', '81%', '90%'),
('Dirty Harry', 'Clint Eastwood', 'Action', 7.7, '$35.9M', '$12.0M', '$47.9M', '89%', '90%'),
('Mystic River', 'Clint Eastwood', 'Crime', 7.9, '$90.1M', '$68.5M', '$158.6M', '88%', '89%'),
('The Outlaw Josey Wales', 'Clint Eastwood', 'Western', 7.8, '$31.8M', '$15.0M', '$46.8M', '90%', '92%'),
('In the Line of Fire', 'Clint Eastwood', 'Action', 7.2, '$102.3M', '$96.2M', '$198.5M', '96%', '76%'),
('American Sniper', 'Clint Eastwood', 'Action', 7.3, '$350.1M', '$197.0M', '$547.1M', '72%', '84%'),
('The Mule', 'Clint Eastwood', 'Crime', 7, '$103.8M', '$69.8M', '$173.6M', '70%', '66%'),
('Space Cowboys', 'Clint Eastwood', 'Action', 6.4, '$90.5M', '$38.0M', '$128.5M', '78%', '53%'),
('Flags of Our Fathers', 'Clint Eastwood', 'Drama', 7.1, '$33.6M', '$42.0M', '$75.6M', '73%', '69%'),
('Letters from Iwo Jima', 'Clint Eastwood', 'Drama', 7.9, '$13.8M', '$52.0M', '$65.8M', '91%', '86%'),
('Changeling', 'Clint Eastwood', 'Biography', 7.7, '$35.7M', '$77.3M', '$113M', '62%', '82%'),
('Play Misty for Me', 'Clint Eastwood', 'Drama', 7, '$10.6M', '$3.0M', '$13.6M', '83%', '71%'),
('High Plains Drifter', 'Clint Eastwood', 'Western', 7.5, '$15.7M', '$8.0M', '$23.7M', '93%', '87%'),
('The Bridges of Madison County', 'Clint Eastwood', 'Drama', 7.6, '$71.5M', '$110.5M', '$182M', '90%', '87%'),
('Escape from Alcatraz', 'Clint Eastwood', 'Biography', 7.6, '$43.0M', '$20.0M', '$63M', '96%', '86%'),
('Pale Rider', 'Clint Eastwood', 'Western', 7.3, '$41.4M', '$6.0M', '$47.4M', '92%', '76%'),
('The Beguiled', 'Clint Eastwood', 'Drama', 7.2, '$10.5M', '$2.0M', '$12.5M', '91%', '73%');

INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('The Godfather Part II', 'Robert De Niro', 'Crime', 9, '$47.5M', '$45.0M', '$92.5M', '96%', '97%'),
('Taxi Driver', 'Robert De Niro', 'Crime', 8.2, '$28.3M', '$19.0M', '$47.3M', '96%', '93%'),
('Raging Bull', 'Robert De Niro', 'Biography', 8.2, '$23.4M', '$10.1M', '$33.5M', '94%', '93%'),
('Goodfellas', 'Robert De Niro', 'Biography', 8.7, '$46.8M', '$47.1M', '$93.9M', '96%', '97%'),
('The Deer Hunter', 'Robert De Niro', 'Drama', 8.1, '$49.0M', '$30.0M', '$79M', '86%', '92%'),
('Heat', 'Robert De Niro', 'Action', 8.3, '$67.4M', '$120.0M', '$187.4M', '88%', '94%'),
('Casino', 'Robert De Niro', 'Crime', 8.2, '$42.5M', '$73.2M', '$115.7M', '79%', '93%'),
('The Irishman', 'Robert De Niro', 'Biography', 7.8, '$8.0M', '$7.0M', '$15M', '95%', '86%'),
('Silver Linings Playbook', 'Robert De Niro', 'Comedy', 7.7, '$132.1M', '$104.5M', '$236.6M', '92%', '86%'),
('The Untouchables', 'Robert De Niro', 'Crime', 7.9, '$76.2M', '$106.2M', '$182.4M', '82%', '89%'),
('Cape Fear', 'Robert De Niro', 'Crime', 7.3, '$79.1M', '$79.0M', '$158.1M', '75%', '77%'),
('Meet the Parents', 'Robert De Niro', 'Comedy', 7, '$166.2M', '$164.2M', '$330.4M', '84%', '79%'),
('Analyze This', 'Robert De Niro', 'Comedy', 6.7, '$107.5M', '$70.0M', '$177.5M', '69%', '60%'),
('Joker', 'Robert De Niro', 'Crime', 8.4, '$335.5M', '$738.0M', '$1073.5M', '69%', '88%'),
('The Mission', 'Robert De Niro', 'Adventure', 7.4, '$17.2M', '$25.0M', '$42.2M', '64%', '83%'),
('A Bronx Tale', 'Robert De Niro', 'Crime', 7.8, '$17.3M', '$9.0M', '$26.3M', '97%', '93%'),
('The King of Comedy', 'Robert De Niro', 'Comedy', 7.8, '$2.5M', '$2.0M', '$4.5M', '89%', '90%'),
('The Intern', 'Robert De Niro', 'Comedy', 7.1, '$75.7M', '$118.8M', '$194.5M', '59%', '73%'),
('The Fan', 'Robert De Niro', 'Drama', 5.9, '$18.6M', '$6.0M', '$24.6M', '37%', '43%'),
('Stardust', 'Robert De Niro', 'Adventure', 7.6, '$38.6M', '$96.0M', '$134.6M', '77%', '86%');

INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('The Godfather', 'Al Pacino', 'Crime', 9.2, '$134.9M', '$110.1M', '$245M', '97%', '98%'),
('Scarface', 'Al Pacino', 'Crime', 8.3, '$45.4M', '$20.4M', '$65.8M', '82%', '93%'),
('The Godfather Part II', 'Al Pacino', 'Crime', 9, '$57.3M', '$47.5M', '$104.8M', '96%', '97%'),
('Heat', 'Al Pacino', 'Action', 8.3, '$67.4M', '$120.0M', '$187.4M', '88%', '94%'),
('Scent of a Woman', 'Al Pacino', 'Drama', 8, '$63.1M', '$71.0M', '$134.1M', '88%', '92%'),
('Dog Day Afternoon', 'Al Pacino', 'Biography', 8, '$50.0M', '$30.0M', '$80M', '96%', '90%'),
('Serpico', 'Al Pacino', 'Biography', 7.7, '$29.8M', '$11.5M', '$41.3M', '90%', '85%'),
('The Irishman', 'Al Pacino', 'Biography', 7.8, '$8.0M', '$7.0M', '$15M', '95%', '86%'),
('Carlito''s Way', 'Al Pacino', 'Crime', 7.9, '$36.9M', '$26.5M', '$63.4M', '81%', '89%'),
('Donnie Brasco', 'Al Pacino', 'Biography', 7.7, '$41.9M', '$63.0M', '$104.9M', '88%', '89%'),
('The Devil''s Advocate', 'Al Pacino', 'Drama', 7.5, '$61.0M', '$92.0M', '$153M', '66%', '80%'),
('The Insider', 'Al Pacino', 'Biography', 7.8, '$29.1M', '$31.2M', '$60.3M', '96%', '90%'),
('Any Given Sunday', 'Al Pacino', 'Drama', 6.9, '$75.5M', '$43.0M', '$118.5M', '52%', '73%'),
('The Godfather Part III', 'Al Pacino', 'Crime', 7.6, '$66.7M', '$70.1M', '$136.8M', '68%', '76%'),
('Insomnia', 'Al Pacino', 'Drama', 7.2, '$67.3M', '$113.8M', '$181.1M', '92%', '77%'),
('Glengarry Glen Ross', 'Al Pacino', 'Drama', 7.7, '$10.7M', '$4.3M', '$15M', '95%', '88%'),
('Ocean''s Thirteen', 'Al Pacino', 'Crime', 6.9, '$117.2M', '$194.3M', '$311.5M', '70%', '75%'),
('The Panic in Needle Park', 'Al Pacino', 'Drama', 7.1, '$13.4M', '$5.0M', '$18.4M', '80%', '75%'),
('Sea of Love', 'Al Pacino', 'Crime', 6.8, '$58.6M', '$52.0M', '$110.6M', '76%', '68%'),
('The Merchant of Venice', 'Al Pacino', 'Drama', 7, '$3.8M', '$18.0M', '$21.8M', '88%', '75%');

INSERT INTO Movies (Movie_Name, Actor, Genre, Imdb_Rating, Domestic_Box_Office, International_Box_Office, Total_Collection, Rotten_Tomatoes_Critic, Rotten_Tomatoes_Fan)
VALUES
('Iron Man', 'Robert Downey Jr.', 'Action', 7.9, '$318.4M', '$266.8M', '$585.2M', '94%', '91%'),
('Sherlock Holmes', 'Robert Downey Jr.', 'Action', 7.6, '$209M', '$315M', '$524M', '69%', '77%'),
('The Avengers', 'Robert Downey Jr.', 'Action', 8, '$623.4M', '$895.5M', '$1518.9M', '91%', '92%'),
('Avengers: Endgame', 'Robert Downey Jr.', 'Action', 8.4, '$858.4M', '$1939M', '$2797.4M', '94%', '90%'),
('Tropic Thunder', 'Robert Downey Jr.', 'Comedy', 7, '$110.5M', '$91.3M', '$201.8M', '82%', '70%'),
('Captain America: Civil War', 'Robert Downey Jr.', 'Action', 7.8, '$408.1M', '$745M', '$1153.1M', '90%', '89%'),
('Zodiac', 'Robert Downey Jr.', 'Crime', 7.7, '$33.1M', '$51.7M', '$84.8M', '90%', '77%'),
('Iron Man 3', 'Robert Downey Jr.', 'Action', 7.1, '$409M', '$805.8M', '$1214.8M', '79%', '78%'),
('Spider-Man: Homecoming', 'Robert Downey Jr.', 'Action', 7.4, '$334.2M', '$546M', '$880.2M', '92%', '87%'),
('The Judge', 'Robert Downey Jr.', 'Drama', 7.4, '$47.1M', '$37M', '$84.1M', '48%', '73%'),
('Chef', 'Robert Downey Jr.', 'Comedy', 7.3, '$31.4M', '$9.4M', '$40.8M', '87%', '85%'),
('Avengers: Infinity War', 'Robert Downey Jr.', 'Action', 8.4, '$678.8M', '$1369.5M', '$2048.3M', '85%', '91%'),
('Sherlock Holmes: A Game of Shadows', 'Robert Downey Jr.', 'Action', 7.4, '$186.8M', '$357M', '$543.8M', '59%', '73%'),
('Due Date', 'Robert Downey Jr.', 'Comedy', 6.5, '$100.5M', '$112.2M', '$212.7M', '40%', '56%'),
('Dolittle', 'Robert Downey Jr.', 'Family', 5.6, '$77M', '$169.7M', '$246.7M', '14%', '76%'),
('Good Night, and Good Luck', 'Robert Downey Jr.', 'Drama', 7.4, '$31.5M', '$7.2M', '$38.7M', '93%', '83%'),
('Kiss Kiss Bang Bang', 'Robert Downey Jr.', 'Comedy', 7.5, '$4.2M', '$10.6M', '$14.8M', '86%', '87%'),
('Chaplin', 'Robert Downey Jr.', 'Drama', 7.5, '$9.4M', '$0M', '$9.4M', '60%', '82%'),
('Gothika', 'Robert Downey Jr.', 'Horror', 5.8, '$59.7M', '$81.8M', '$141.5M', '15%', '46%'),
('Wonder Boys', 'Robert Downey Jr.', 'Comedy', 7.2, '$19.4M', '$12M', '$31.4M', '81%', '72%');

