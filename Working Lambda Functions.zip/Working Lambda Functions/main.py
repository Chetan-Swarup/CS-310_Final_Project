import requests
import time
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Base URL for the APIs
baseurl = "https://imme7yw723.execute-api.us-east-2.amazonaws.com/prod"

# List of valid actors
VALID_ACTORS = [
    'Tom_Cruise', 'Christian_Bale', 'Judi_Dench',
    'Sandra_Bullock', 'Meryl_Streep', 'Denzel_Washington',
    'Tom_Hanks', 'Clint_Eastwood', 'Robert_De_Niro',
    'Al_Pacino', 'Robert_Downey_Jr'
]

# Retry configuration
RETRY_LIMIT = 3
RETRY_DELAY = 2  # seconds


def fetch_with_retry(url):
    """
    Fetches data from the specified URL with retry logic for server errors.

    Parameters:
    - url (str): The URL to fetch data from.

    Returns:
    - dict: The JSON response if successful.
    - None: If the request fails after retries.
    """
    for attempt in range(RETRY_LIMIT):
        try:
            response = requests.get(url)
            response.raise_for_status()  # Raise an exception for HTTP errors
            return response.json()  # Return the JSON response
        except requests.exceptions.RequestException as e:
            logging.warning(f"Attempt {attempt + 1}/{RETRY_LIMIT} failed: {e}")
            if attempt < RETRY_LIMIT - 1:
                logging.info(f"Retrying in {RETRY_DELAY} seconds...")
                time.sleep(RETRY_DELAY)
            else:
                logging.error("Max retries reached. Skipping this request.")
                return None


def display_actor_data(actor_name):
    """
    Calls all APIs for the specified actor and displays the results in a structured format.

    Parameters:
    - actor_name (str): The actor name to query.

    Returns:
    - None
    """
    try:
        if actor_name not in VALID_ACTORS:
            print(f"\nInvalid actor name. Please choose from the following:")
            print("\n".join(VALID_ACTORS))
            return

        print(f"\nFetching data for actor: {actor_name}\n")

        # Average Box Office
        avg_box_office_url = f"{baseurl}/avg_Box_Office/{actor_name}"
        avg_box_office_data = fetch_with_retry(avg_box_office_url)
        average_box_office = avg_box_office_data.get("average_box_office", "N/A") if avg_box_office_data else "N/A"
        print(f"Average Box Office: {average_box_office}")

        # Average Fan Score
        avg_fan_score_url = f"{baseurl}/avg_Fan_Score/{actor_name}"
        avg_fan_score_data = fetch_with_retry(avg_fan_score_url)
        average_fan_score = avg_fan_score_data.get("average_fan_score", "N/A") if avg_fan_score_data else "N/A"
        print(f"Average Fan Score: {average_fan_score}")

        # Average Critic Score
        avg_critic_score_url = f"{baseurl}/avg_Critic_Score/{actor_name}"
        avg_critic_score_data = fetch_with_retry(avg_critic_score_url)
        average_critic_score = avg_critic_score_data.get("average_critic_score", "N/A") if avg_critic_score_data else "N/A"
        print(f"Average Critic Score: {average_critic_score}")

        # Genre Count
        avg_genre_count_url = f"{baseurl}/avg_Genre_Count/{actor_name}"
        avg_genre_count_data = fetch_with_retry(avg_genre_count_url)
        if avg_genre_count_data:
            highest_genres = avg_genre_count_data.get("highest_genres", [])
            if highest_genres:
                print("Highest Genres:")
                for genre_data in highest_genres:
                    genre = genre_data.get("genre", "Unknown")
                    count = genre_data.get("count", 0)
                    print(f"- Genre: {genre}, Count: {count}")
            else:
                print("No genre information available.")
        else:
            print("No genre information available.")

        # Average IMDB Rating
        avg_imdb_rating_url = f"{baseurl}/avg_Imdb_Rating/{actor_name}"
        avg_imdb_rating_data = fetch_with_retry(avg_imdb_rating_url)
        avg_imdb_rating = avg_imdb_rating_data.get("average_rating", "N/A") if avg_imdb_rating_data else "N/A"
        print(f"Average IMDB Rating: {avg_imdb_rating}")

    except ValueError:
        logging.error("Error parsing JSON response.")
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")


if __name__ == "__main__":
    print("Welcome to Movie Analytics!")
    print("Here are the actors you can choose from:")
    print("\n".join(VALID_ACTORS))

    while True:
        print("\nEnter the actor name (or type 'exit' to quit):")
        actor_name = input().strip()

        if actor_name.lower() == "exit":
            print("Exiting... Goodbye!")
            break

        display_actor_data(actor_name)
